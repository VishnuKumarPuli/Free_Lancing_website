import { useState } from 'react';
import { Link, useRouterState } from '@tanstack/react-router';
import { useGetCallerUserProfile } from '../hooks/useGetCallerUserProfile';
import { useIsCallerAdmin } from '../hooks/useQueries';
import { Menu, X, Briefcase, User, FolderOpen, FileText, MessageSquare, Users, LayoutDashboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export default function Navigation() {
  const [open, setOpen] = useState(false);
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: isAdmin } = useIsCallerAdmin();
  const router = useRouterState();
  const currentPath = router.location.pathname;

  const isActive = (path: string) => currentPath === path;

  const navItems = [
    { path: '/projects', label: 'Browse Projects', icon: Briefcase, show: true },
    { path: '/freelancers', label: 'Find Freelancers', icon: Users, show: true },
    { path: '/profile', label: 'My Profile', icon: User, show: true },
    { path: '/my-projects', label: 'My Projects', icon: FolderOpen, show: true },
    { path: '/my-applications', label: 'My Applications', icon: FileText, show: true },
    { path: '/messages', label: 'Messages', icon: MessageSquare, show: true },
    { path: '/admin', label: 'Admin Dashboard', icon: LayoutDashboard, show: isAdmin },
  ];

  const NavLinks = () => (
    <>
      {navItems
        .filter((item) => item.show)
        .map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                isActive(item.path)
                  ? 'bg-teal-100 dark:bg-teal-900/30 text-teal-900 dark:text-teal-100'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
              onClick={() => setOpen(false)}
            >
              <Icon className="h-4 w-4" />
              <span className="lg:inline hidden">{item.label}</span>
            </Link>
          );
        })}
    </>
  );

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:flex items-center gap-2">
        <NavLinks />
      </nav>

      {/* Mobile Navigation */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild className="md:hidden">
          <Button variant="ghost" size="icon">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64">
          <div className="flex flex-col gap-4 mt-8">
            <div className="flex items-center gap-2 px-3 pb-4 border-b">
              <img
                src={userProfile?.profilePictureUrl || '/assets/generated/default-avatar.dim_200x200.png'}
                alt="Profile"
                className="h-10 w-10 rounded-full object-cover"
              />
              <div className="flex flex-col">
                <span className="text-sm font-medium">{userProfile?.bio || 'User'}</span>
                {isAdmin && <span className="text-xs text-muted-foreground">Admin</span>}
              </div>
            </div>
            <nav className="flex flex-col gap-2">
              <NavLinks />
            </nav>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
