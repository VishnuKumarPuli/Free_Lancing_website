import { useParams } from '@tanstack/react-router';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users } from 'lucide-react';

export default function ProjectApplications() {
  const { projectId } = useParams({ from: '/projects/$projectId/applications' });

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Project Applications</h1>
        <p className="text-muted-foreground">Review and manage freelancer applications</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Applications
          </CardTitle>
          <CardDescription>Freelancers who applied to this project</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No applications yet. Share your project to attract freelancers!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
