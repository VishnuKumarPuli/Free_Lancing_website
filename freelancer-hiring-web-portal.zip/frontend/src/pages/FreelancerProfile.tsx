import { useState } from 'react';
import { useGetCallerUserProfile } from '../hooks/useGetCallerUserProfile';
import { useSaveCallerUserProfile } from '../hooks/useSaveCallerUserProfile';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Edit, Save, X, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function FreelancerProfile() {
  const { identity } = useInternetIdentity();
  const { data: userProfile, isLoading } = useGetCallerUserProfile();
  const saveProfile = useSaveCallerUserProfile();
  const [isEditing, setIsEditing] = useState(false);

  const [bio, setBio] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [portfolioLinks, setPortfolioLinks] = useState<string[]>([]);
  const [newLink, setNewLink] = useState('');
  const [hourlyRate, setHourlyRate] = useState('');
  const [experienceYears, setExperienceYears] = useState('');
  const [profilePictureUrl, setProfilePictureUrl] = useState('');

  const handleEdit = () => {
    if (userProfile) {
      setBio(userProfile.bio);
      setSkills(userProfile.skills);
      setPortfolioLinks(userProfile.portfolioLinks);
      setHourlyRate(userProfile.hourlyRate.toString());
      setExperienceYears(userProfile.experienceYears.toString());
      setProfilePictureUrl(userProfile.profilePictureUrl);
    }
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setNewSkill('');
    setNewLink('');
  };

  const handleSave = async () => {
    if (!identity) return;

    try {
      await saveProfile.mutateAsync({
        principal: identity.getPrincipal(),
        bio,
        skills,
        portfolioLinks,
        hourlyRate: BigInt(hourlyRate || 0),
        experienceYears: BigInt(experienceYears || 0),
        profilePictureUrl: profilePictureUrl || '/assets/generated/default-avatar.dim_200x200.png',
      });
      setIsEditing(false);
      toast.success('Profile updated successfully!');
    } catch (error) {
      toast.error('Failed to update profile');
      console.error('Failed to save profile:', error);
    }
  };

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const removeSkill = (skill: string) => {
    setSkills(skills.filter((s) => s !== skill));
  };

  const addLink = () => {
    if (newLink.trim() && !portfolioLinks.includes(newLink.trim())) {
      setPortfolioLinks([...portfolioLinks, newLink.trim()]);
      setNewLink('');
    }
  };

  const removeLink = (link: string) => {
    setPortfolioLinks(portfolioLinks.filter((l) => l !== link));
  };

  if (isLoading) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <Card>
          <CardContent className="p-8 text-center">Loading profile...</CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl">My Profile</CardTitle>
              <CardDescription>Manage your freelancer profile information</CardDescription>
            </div>
            {!isEditing ? (
              <Button onClick={handleEdit}>
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button onClick={handleSave} disabled={saveProfile.isPending}>
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button variant="outline" onClick={handleCancel}>
                  <X className="h-4 w-4 mr-2" />
                  Cancel
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Profile Picture */}
          <div className="flex items-center gap-4">
            <img
              src={
                isEditing && profilePictureUrl
                  ? profilePictureUrl
                  : userProfile?.profilePictureUrl || '/assets/generated/default-avatar.dim_200x200.png'
              }
              alt="Profile"
              className="h-24 w-24 rounded-full object-cover border-4 border-teal-100 dark:border-teal-900"
            />
            {isEditing && (
              <div className="flex-1">
                <Label htmlFor="profilePicture">Profile Picture URL</Label>
                <Input
                  id="profilePicture"
                  value={profilePictureUrl}
                  onChange={(e) => setProfilePictureUrl(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
            )}
          </div>

          {/* Bio */}
          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            {isEditing ? (
              <Textarea
                id="bio"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Tell us about yourself"
                rows={4}
              />
            ) : (
              <p className="text-sm text-muted-foreground">{userProfile?.bio || 'No bio provided'}</p>
            )}
          </div>

          {/* Skills */}
          <div className="space-y-2">
            <Label>Skills</Label>
            <div className="flex flex-wrap gap-2">
              {(isEditing ? skills : userProfile?.skills || []).map((skill) => (
                <Badge key={skill} variant="secondary" className="gap-1">
                  {skill}
                  {isEditing && (
                    <button onClick={() => removeSkill(skill)} className="ml-1 hover:text-destructive">
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </Badge>
              ))}
            </div>
            {isEditing && (
              <div className="flex gap-2 mt-2">
                <Input
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  placeholder="Add a skill"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
                />
                <Button type="button" onClick={addSkill} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>

          {/* Experience & Rate */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="experience">Years of Experience</Label>
              {isEditing ? (
                <Input
                  id="experience"
                  type="number"
                  value={experienceYears}
                  onChange={(e) => setExperienceYears(e.target.value)}
                  placeholder="0"
                  min="0"
                />
              ) : (
                <p className="text-sm text-muted-foreground">
                  {userProfile?.experienceYears.toString() || '0'} years
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="rate">Hourly Rate ($)</Label>
              {isEditing ? (
                <Input
                  id="rate"
                  type="number"
                  value={hourlyRate}
                  onChange={(e) => setHourlyRate(e.target.value)}
                  placeholder="0"
                  min="0"
                />
              ) : (
                <p className="text-sm text-muted-foreground">${userProfile?.hourlyRate.toString() || '0'}/hour</p>
              )}
            </div>
          </div>

          {/* Portfolio Links */}
          <div className="space-y-2">
            <Label>Portfolio Links</Label>
            <div className="space-y-2">
              {(isEditing ? portfolioLinks : userProfile?.portfolioLinks || []).map((link) => (
                <div key={link} className="flex items-center gap-2">
                  <a
                    href={link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-teal-600 hover:underline flex-1 truncate"
                  >
                    {link}
                  </a>
                  {isEditing && (
                    <Button variant="ghost" size="sm" onClick={() => removeLink(link)}>
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
            {isEditing && (
              <div className="flex gap-2 mt-2">
                <Input
                  value={newLink}
                  onChange={(e) => setNewLink(e.target.value)}
                  placeholder="https://portfolio.com"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addLink())}
                />
                <Button type="button" onClick={addLink} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
