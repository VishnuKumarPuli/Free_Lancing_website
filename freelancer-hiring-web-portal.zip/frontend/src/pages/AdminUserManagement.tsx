import { useIsCallerAdmin, useListApprovals, useSetApproval } from '../hooks/useQueries';
import AccessDenied from '../components/AccessDenied';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Users, Check, X } from 'lucide-react';
import { ApprovalStatus } from '../backend';
import { toast } from 'sonner';

export default function AdminUserManagement() {
  const { data: isAdmin, isLoading: adminLoading } = useIsCallerAdmin();
  const { data: approvals = [], isLoading: approvalsLoading } = useListApprovals();
  const setApproval = useSetApproval();

  const handleApproval = async (userPrincipal: string, status: ApprovalStatus) => {
    try {
      await setApproval.mutateAsync({
        user: { toText: () => userPrincipal } as any,
        status,
      });
      toast.success(`User ${status === ApprovalStatus.approved ? 'approved' : 'rejected'} successfully`);
    } catch (error) {
      toast.error('Failed to update user status');
      console.error('Failed to update approval:', error);
    }
  };

  if (adminLoading) {
    return (
      <div className="container max-w-6xl mx-auto px-4 py-8">
        <Card>
          <CardContent className="p-8 text-center">Loading...</CardContent>
        </Card>
      </div>
    );
  }

  if (!isAdmin) {
    return <AccessDenied />;
  }

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Users className="h-8 w-8" />
          User Management
        </h1>
        <p className="text-muted-foreground">Manage user accounts and approvals</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Approvals</CardTitle>
          <CardDescription>Review and approve user accounts</CardDescription>
        </CardHeader>
        <CardContent>
          {approvalsLoading ? (
            <div className="text-center py-8">Loading users...</div>
          ) : approvals.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No users to review</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Principal</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {approvals.map((approval) => (
                  <TableRow key={approval.principal.toString()}>
                    <TableCell className="font-mono text-xs">{approval.principal.toString().slice(0, 20)}...</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          approval.status === ApprovalStatus.approved
                            ? 'default'
                            : approval.status === ApprovalStatus.rejected
                              ? 'destructive'
                              : 'secondary'
                        }
                      >
                        {approval.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {approval.status !== ApprovalStatus.approved && (
                          <Button
                            size="sm"
                            variant="default"
                            onClick={() => handleApproval(approval.principal.toString(), ApprovalStatus.approved)}
                            disabled={setApproval.isPending}
                          >
                            <Check className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                        )}
                        {approval.status !== ApprovalStatus.rejected && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleApproval(approval.principal.toString(), ApprovalStatus.rejected)}
                            disabled={setApproval.isPending}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
