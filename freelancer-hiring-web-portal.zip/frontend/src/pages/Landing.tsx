import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetCallerUserProfile } from '../hooks/useGetCallerUserProfile';
import { useNavigate } from '@tanstack/react-router';
import { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Briefcase, Users, MessageSquare, Shield, TrendingUp, Clock } from 'lucide-react';

export default function Landing() {
  const { identity, login } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const navigate = useNavigate();

  useEffect(() => {
    if (identity && userProfile) {
      navigate({ to: '/projects' });
    }
  }, [identity, userProfile, navigate]);

  const features = [
    {
      icon: Briefcase,
      title: 'Browse Projects',
      description: 'Discover exciting opportunities from clients worldwide',
    },
    {
      icon: Users,
      title: 'Find Talent',
      description: 'Connect with skilled freelancers for your projects',
    },
    {
      icon: MessageSquare,
      title: 'Direct Communication',
      description: 'Chat directly with clients and freelancers',
    },
    {
      icon: Shield,
      title: 'Secure Platform',
      description: 'Built on Internet Computer for maximum security',
    },
    {
      icon: TrendingUp,
      title: 'Track Progress',
      description: 'Monitor applications and project status in real-time',
    },
    {
      icon: Clock,
      title: 'Flexible Work',
      description: 'Work on your terms with transparent timelines',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section
        className="relative bg-gradient-to-br from-teal-600 to-amber-600 text-white py-20 md:py-32"
        style={{
          backgroundImage: 'url(/assets/generated/hero-bg.dim_1920x600.png)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundBlendMode: 'overlay',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-teal-900/80 to-amber-900/80" />
        <div className="container relative z-10 px-4 mx-auto text-center">
          <img
            src="/assets/generated/logo-icon.dim_256x256.png"
            alt="FreelanceHub"
            className="h-20 w-20 mx-auto mb-6"
          />
          <h1 className="text-4xl md:text-6xl font-bold mb-6">Welcome to FreelanceHub</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
            Connect with talented freelancers or find your next project. Built on the Internet Computer for a secure,
            decentralized experience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={login} className="bg-white text-teal-900 hover:bg-gray-100">
              Get Started
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="container px-4 mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose FreelanceHub?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A modern platform designed to make freelancing and hiring seamless and secure
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-teal-100 dark:bg-teal-900/30">
                        <Icon className="h-6 w-6 text-teal-600 dark:text-teal-400" />
                      </div>
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-teal-600 to-amber-600 text-white">
        <div className="container px-4 mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of freelancers and clients building the future of work
          </p>
          <Button size="lg" onClick={login} className="bg-white text-teal-900 hover:bg-gray-100">
            Sign Up Now
          </Button>
        </div>
      </section>
    </div>
  );
}
