import { useGetNotifications, useMarkNotificationAsRead } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Check } from 'lucide-react';
import { toast } from 'sonner';

export default function Notifications() {
  const { data: notifications = [], isLoading } = useGetNotifications();
  const markAsRead = useMarkNotificationAsRead();

  const unreadNotifications = notifications.filter((n) => !n.read);
  const readNotifications = notifications.filter((n) => n.read);

  const handleMarkAsRead = async (notificationId: bigint) => {
    try {
      await markAsRead.mutateAsync(notificationId);
      toast.success('Notification marked as read');
    } catch (error) {
      toast.error('Failed to mark notification as read');
      console.error('Failed to mark notification as read:', error);
    }
  };

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Bell className="h-8 w-8" />
          Notifications
        </h1>
        <p className="text-muted-foreground">Stay updated with your activity</p>
      </div>

      {isLoading ? (
        <Card>
          <CardContent className="p-8 text-center">Loading notifications...</CardContent>
        </Card>
      ) : notifications.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-muted-foreground">
            <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No notifications yet</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {unreadNotifications.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Unread</span>
                  <Badge>{unreadNotifications.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {unreadNotifications.map((notification) => (
                  <div
                    key={notification.id.toString()}
                    className="flex items-start justify-between p-4 border rounded-lg bg-teal-50 dark:bg-teal-950/20"
                  >
                    <p className="text-sm flex-1">{notification.message}</p>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleMarkAsRead(notification.id)}
                      disabled={markAsRead.isPending}
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {readNotifications.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Read</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {readNotifications.map((notification) => (
                  <div key={notification.id.toString()} className="p-4 border rounded-lg opacity-60">
                    <p className="text-sm">{notification.message}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}
