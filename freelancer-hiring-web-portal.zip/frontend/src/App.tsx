import { createRouter, RouterProvider, createRoute, createRootRoute, Outlet } from '@tanstack/react-router';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile } from './hooks/useGetCallerUserProfile';
import ProfileSetupModal from './components/ProfileSetupModal';
import Layout from './components/Layout';
import Landing from './pages/Landing';
import FreelancerProfile from './pages/FreelancerProfile';
import CreateProject from './pages/CreateProject';
import ClientProjects from './pages/ClientProjects';
import BrowseProjects from './pages/BrowseProjects';
import MyApplications from './pages/MyApplications';
import ProjectApplications from './pages/ProjectApplications';
import ProjectDetails from './pages/ProjectDetails';
import Messages from './pages/Messages';
import Conversation from './pages/Conversation';
import AdminDashboard from './pages/AdminDashboard';
import AdminUserManagement from './pages/AdminUserManagement';
import AdminProjectMonitoring from './pages/AdminProjectMonitoring';
import SearchFreelancers from './pages/SearchFreelancers';
import Notifications from './pages/Notifications';

function RootComponent() {
  const { identity } = useInternetIdentity();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  return (
    <>
      {showProfileSetup && <ProfileSetupModal />}
      <Layout>
        <Outlet />
      </Layout>
    </>
  );
}

const rootRoute = createRootRoute({
  component: RootComponent,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: Landing,
});

const profileRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/profile',
  component: FreelancerProfile,
});

const createProjectRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/projects/new',
  component: CreateProject,
});

const clientProjectsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/my-projects',
  component: ClientProjects,
});

const browseProjectsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/projects',
  component: BrowseProjects,
});

const myApplicationsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/my-applications',
  component: MyApplications,
});

const projectApplicationsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/projects/$projectId/applications',
  component: ProjectApplications,
});

const projectDetailsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/projects/$projectId',
  component: ProjectDetails,
});

const messagesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/messages',
  component: Messages,
});

const conversationRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/messages/$projectId/$participantId',
  component: Conversation,
});

const adminDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin',
  component: AdminDashboard,
});

const adminUserManagementRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/users',
  component: AdminUserManagement,
});

const adminProjectMonitoringRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/admin/projects',
  component: AdminProjectMonitoring,
});

const searchFreelancersRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/freelancers',
  component: SearchFreelancers,
});

const notificationsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/notifications',
  component: Notifications,
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  profileRoute,
  createProjectRoute,
  clientProjectsRoute,
  browseProjectsRoute,
  myApplicationsRoute,
  projectApplicationsRoute,
  projectDetailsRoute,
  messagesRoute,
  conversationRoute,
  adminDashboardRoute,
  adminUserManagementRoute,
  adminProjectMonitoringRoute,
  searchFreelancersRoute,
  notificationsRoute,
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
