import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type {
  FreelancerProfile,
  Project,
  Application,
  Message,
  Notification,
  Timeline,
  ApplicationStatus,
  ApprovalStatus,
  UserRole,
} from '../backend';
import { Principal } from '@dfinity/principal';

export function useGetCallerUserRole() {
  const { actor, isFetching } = useActor();

  return useQuery<UserRole>({
    queryKey: ['callerUserRole'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserRole();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useIsCallerAdmin() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isCallerAdmin'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useIsCallerApproved() {
  const { actor, isFetching } = useActor();

  return useQuery<boolean>({
    queryKey: ['isCallerApproved'],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerApproved();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useRequestApproval() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.requestApproval();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['isCallerApproved'] });
    },
  });
}

export function useGetAllFreelancers() {
  const { actor, isFetching } = useActor();

  return useQuery<FreelancerProfile[]>({
    queryKey: ['allFreelancers'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllFreelancers();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetUserProfile(userPrincipal: Principal | null) {
  const { actor, isFetching } = useActor();

  return useQuery<FreelancerProfile | null>({
    queryKey: ['userProfile', userPrincipal?.toString()],
    queryFn: async () => {
      if (!actor || !userPrincipal) return null;
      return actor.getUserProfile(userPrincipal);
    },
    enabled: !!actor && !isFetching && !!userPrincipal,
  });
}

export function useCreateProject() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      title,
      description,
      budget,
      timeline,
      requiredSkills,
    }: {
      title: string;
      description: string;
      budget: bigint;
      timeline: Timeline;
      requiredSkills: string[];
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.createProject(title, description, budget, timeline, requiredSkills);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clientProjects'] });
      queryClient.invalidateQueries({ queryKey: ['allProjects'] });
    },
  });
}

export function useGetProject(projectId: bigint | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Project | null>({
    queryKey: ['project', projectId?.toString()],
    queryFn: async () => {
      if (!actor || projectId === null) return null;
      return actor.getProject(projectId);
    },
    enabled: !!actor && !isFetching && projectId !== null,
  });
}

export function useApplyToProject() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (projectId: bigint) => {
      if (!actor) throw new Error('Actor not available');
      return actor.applyToProject(projectId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myApplications'] });
      queryClient.invalidateQueries({ queryKey: ['projectApplications'] });
    },
  });
}

export function useGetProjectApplications(projectId: bigint | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Application[]>({
    queryKey: ['projectApplications', projectId?.toString()],
    queryFn: async () => {
      if (!actor || projectId === null) return [];
      return actor.getProjectApplications(projectId);
    },
    enabled: !!actor && !isFetching && projectId !== null,
  });
}

export function useUpdateApplicationStatus() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      applicationId,
      status,
    }: {
      applicationId: bigint;
      status: ApplicationStatus;
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateApplicationStatus(applicationId, status);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projectApplications'] });
      queryClient.invalidateQueries({ queryKey: ['myApplications'] });
    },
  });
}

export function useSendMessage() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      recipient,
      projectId,
      messageText,
      timestamp,
    }: {
      recipient: Principal;
      projectId: bigint;
      messageText: string;
      timestamp: bigint;
    }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.sendMessage(recipient, projectId, messageText, timestamp);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['projectMessages', variables.projectId.toString()] });
    },
  });
}

export function useGetProjectMessages(projectId: bigint | null) {
  const { actor, isFetching } = useActor();

  return useQuery<Message[]>({
    queryKey: ['projectMessages', projectId?.toString()],
    queryFn: async () => {
      if (!actor || projectId === null) return [];
      return actor.getProjectMessages(projectId);
    },
    enabled: !!actor && !isFetching && projectId !== null,
  });
}

export function useGetNotifications() {
  const { actor, isFetching } = useActor();

  return useQuery<Notification[]>({
    queryKey: ['notifications'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getNotifications();
    },
    enabled: !!actor && !isFetching,
    refetchInterval: 30000,
  });
}

export function useMarkNotificationAsRead() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (notificationId: bigint) => {
      if (!actor) throw new Error('Actor not available');
      return actor.markNotificationAsRead(notificationId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}

export function useGetAnalytics() {
  const { actor, isFetching } = useActor();

  return useQuery<{ totalProjects: bigint; totalApplications: bigint }>({
    queryKey: ['analytics'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getAnalytics();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useListApprovals() {
  const { actor, isFetching } = useActor();

  return useQuery({
    queryKey: ['approvals'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.listApprovals();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSetApproval() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ user, status }: { user: Principal; status: ApprovalStatus }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.setApproval(user, status);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['approvals'] });
    },
  });
}
