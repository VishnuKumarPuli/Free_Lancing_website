import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface UserApprovalInfo {
    status: ApprovalStatus;
    principal: Principal;
}
export interface Application {
    id: bigint;
    status: ApplicationStatus;
    projectId: bigint;
    freelancer: Principal;
}
export interface Notification {
    id: bigint;
    read: boolean;
    user: Principal;
    message: string;
}
export interface FreelancerProfile {
    bio: string;
    principal: Principal;
    hourlyRate: bigint;
    experienceYears: bigint;
    profilePictureUrl: string;
    portfolioLinks: Array<string>;
    skills: Array<string>;
}
export interface Message {
    id: bigint;
    recipient: Principal;
    sender: Principal;
    projectId: bigint;
    message: string;
    timestamp: bigint;
}
export interface Timeline {
    endDate: bigint;
    startDate: bigint;
}
export interface Project {
    id: bigint;
    status: ProjectStatus;
    client: Principal;
    title: string;
    description: string;
    assignedFreelancer?: Principal;
    budget: bigint;
    requiredSkills: Array<string>;
    timeline: Timeline;
}
export enum ApplicationStatus {
    pending = "pending",
    rejected = "rejected",
    shortlisted = "shortlisted",
    accepted = "accepted"
}
export enum ApprovalStatus {
    pending = "pending",
    approved = "approved",
    rejected = "rejected"
}
export enum ProjectStatus {
    open = "open",
    completed = "completed",
    inProgress = "inProgress"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    adminSetUserApproval(user: Principal, status: ApprovalStatus): Promise<void>;
    applyToProject(projectId: bigint): Promise<bigint>;
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    createProject(title: string, description: string, budget: bigint, timeline: Timeline, requiredSkills: Array<string>): Promise<bigint>;
    getAllFreelancers(): Promise<Array<FreelancerProfile>>;
    getAnalytics(): Promise<{
        totalProjects: bigint;
        totalApplications: bigint;
    }>;
    getCallerUserProfile(): Promise<FreelancerProfile | null>;
    getCallerUserRole(): Promise<UserRole>;
    getNotifications(): Promise<Array<Notification>>;
    getProject(projectId: bigint): Promise<Project | null>;
    getProjectApplications(projectId: bigint): Promise<Array<Application>>;
    getProjectMessages(projectId: bigint): Promise<Array<Message>>;
    getUserProfile(user: Principal): Promise<FreelancerProfile | null>;
    isCallerAdmin(): Promise<boolean>;
    isCallerApproved(): Promise<boolean>;
    listApprovals(): Promise<Array<UserApprovalInfo>>;
    markNotificationAsRead(notificationId: bigint): Promise<void>;
    requestApproval(): Promise<void>;
    saveCallerUserProfile(profile: FreelancerProfile): Promise<void>;
    sendMessage(recipient: Principal, projectId: bigint, messageText: string, timestamp: bigint): Promise<bigint>;
    setApproval(user: Principal, status: ApprovalStatus): Promise<void>;
    updateApplicationStatus(applicationId: bigint, status: ApplicationStatus): Promise<void>;
}
